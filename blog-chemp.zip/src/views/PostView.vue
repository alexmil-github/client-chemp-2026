<script>
export default {
  name: "PostView"
}
</script>

<template>
  <div id="postPage" class="page">
    <a href="#indexPage" class="btn btn-secondary mb-4">← Назад к постам</a>
    <h2 class="mb-4">Путешествие в горы</h2>

    <div class="d-flex justify-content-between align-items-center mb-3">
      <div>
        <span class="badge bg-success">Алексей Иванов</span>
        <span class="text-muted ms-2">2025-01-26 14:30</span>
      </div>
      <div>
                    <span class="like-btn me-3">
                        ❤️ <span>24</span>
                    </span>
        <span>💬 <span>8</span></span>
      </div>
    </div>

    <img src="https://placeholder.apptor.studio/800/400/product1.png" alt="Изображение поста" class="img-fluid mb-4 rounded post-image-large">
    <p class="mb-5">Полный текст поста о незабываемом приключении в Альпах с захватывающими видами и экстремальными маршрутами. Это был удивительный опыт, который запомнится на всю жизнь.</p>

    <h4 class="mt-3 mb-4">Комментарии</h4>
    <form class="mb-4">
      <textarea rows="3" class="form-control" placeholder="Введите комментарий">Отличный пост! Спасибо за полезную информацию.</textarea>
      <button type="submit" class="btn btn-success mt-2">Отправить</button>
    </form>


    <div class="comments">
      <!-- Комментарий 1 -->
      <div class="card mb-3">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start">
            <div class="d-flex align-items-center mb-2">
              <div class="comment-avatar">МП</div>
              <div>
                <h5 class="card-title mb-0">Мария Петрова</h5>
                <small class="card-text text-muted">2 часа назад</small>
              </div>
            </div>
            <button class="btn btn-sm btn-outline-danger">Удалить</button>
          </div>
          <p class="card-text">Очень интересно, жду продолжения!</p>
          <div class="mt-2">
            <button class="btn btn-sm btn-outline-primary">🔍 Проверить лайк</button>

          </div>
        </div>
      </div>

      <!-- Комментарий 2 -->
      <div class="card mb-3">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start">
            <div class="d-flex align-items-center mb-2">
              <div class="comment-avatar">ДС</div>
              <div>
                <h5 class="card-title mb-0">Дмитрий Смирнов</h5>
                <small class="card-text text-muted">Вчера</small>
              </div>
            </div>
            <button class="btn btn-sm btn-outline-danger">Удалить</button>
          </div>
          <p class="card-text">Есть вопросы по реализации, можно подробнее?</p>
          <div class="mt-2">
            <button class="btn btn-sm btn-outline-primary">🔍 Проверить лайк</button>

          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>