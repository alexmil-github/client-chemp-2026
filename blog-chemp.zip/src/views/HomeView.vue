<script>
export default {
  name: "HomeView"
}
</script>

<template>
  <div id="indexPage" class="page">
    <!-- Поиск и сортировка ТОЛЬКО на главной -->
    <div class="row mb-4">
      <div class="col-md-6 search-box">
        <input type="text" class="form-control" placeholder="Поиск постов...">

      </div>
      <div class="col-md-6 sort-options">
        <select class="form-control">
          <option value="newest">Сначала новые</option>
          <option value="popular" selected>По популярности</option>
          <option value="most_commented">По комментариям</option>
        </select>
      </div>
    </div>

    <div class="row">
      <!-- Карточка 1 -->
      <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
        <div class="card h-100">
          <img src="https://placeholder.apptor.studio/300/200/product1.png" class="card-img-top" alt="Путешествие в горы">
          <div class="card-body d-flex flex-column">
            <div class="badge bg-success mb-2">Алексей Иванов</div>
            <h5 class="card-title">Путешествие в горы</h5>
            <p class="card-text flex-grow-1">Незабываемое приключение в Альпах с захватывающими видами и экстремальными маршрутами.</p>
            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="like-btn liked">
                                    ❤️ <span>24</span>
                                </span>
              <span>💬 <span>8</span></span>
            </div>
            <a href="#postPage?id=1" class="btn btn-primary">Читать пост</a>
          </div>
        </div>
      </div>

      <!-- Карточка 2 -->
      <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
        <div class="card h-100">
          <img src="https://placeholder.apptor.studio/300/200/product2.png" class="card-img-top" alt="Рецепты здорового питания">
          <div class="card-body d-flex flex-column">
            <div class="badge bg-success mb-2">Мария Петрова</div>
            <h5 class="card-title">Рецепты здорового питания</h5>
            <p class="card-text flex-grow-1">Секреты приготовления полезных и вкусных блюд для всей семьи на каждый день.</p>
            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="like-btn">
                                    ❤️ <span>156</span>
                                </span>
              <span>💬 <span>42</span></span>
            </div>
            <a href="#postPage?id=2" class="btn btn-primary">Читать пост</a>
          </div>
        </div>
      </div>

      <!-- Карточка 3 -->
      <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
        <div class="card h-100">
          <img src="https://placeholder.apptor.studio/300/200/product3.png" class="card-img-top" alt="Программирование на Python">
          <div class="card-body d-flex flex-column">
            <div class="badge bg-success mb-2">Дмитрий Смирнов</div>
            <h5 class="card-title">Программирование на Python</h5>
            <p class="card-text flex-grow-1">Основы языка Python для начинающих разработчиков с практическими примерами.</p>
            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="like-btn liked">
                                    ❤️ <span>89</span>
                                </span>
              <span>💬 <span>17</span></span>
            </div>
            <a href="#postPage?id=3" class="btn btn-primary">Читать пост</a>
          </div>
        </div>
      </div>

      <!-- Карточка 4 -->
      <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
        <div class="card h-100">
          <img src="https://placeholder.apptor.studio/300/200/product4.png" class="card-img-top" alt="Искусство фотографии">
          <div class="card-body d-flex flex-column">
            <div class="badge bg-success mb-2">Ольга Козлова</div>
            <h5 class="card-title">Искусство фотографии</h5>
            <p class="card-text flex-grow-1">Как делать профессиональные фотографии на обычный смартфон. Советы и трюки.</p>
            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="like-btn">
                                    ❤️ <span>203</span>
                                </span>
              <span>💬 <span>56</span></span>
            </div>
            <a href="#postPage?id=4" class="btn btn-primary">Читать пост</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>